module Main where

import System.Directory (doesDirectoryExist, listDirectory)
import System.FilePath ((</>), takeExtension)
import Control.Monad (forM, filterM)
import Language.Python.Version3.Parser (parseModule)
import Language.Python.Common.AST
import Language.Python.Common.Pretty (prettyText)
import qualified Data.Text.IO as T

-- Função principal que recebe o caminho de um diretório
main :: IO ()
main = do
    folderPath <- getLine
    pyFiles <- findPythonFiles folderPath
    mapM_ processPythonFile pyFiles

-- Função que encontra os arquivos Python em um diretório
findPythonFiles :: FilePath -> IO [FilePath]
findPythonFiles path = do
    contents <- listDirectory path
    let paths = map (path </>) contents

    dirs <- filterM doesDirectoryExist paths
    files <- filterM (\p -> return $ takeExtension p == ".py") paths

    nestedFiles <- mapM findPythonFiles dirs
    return $ files ++ concat nestedFiles

-- Função que processa cada arquivo .py
processPythonFile :: FilePath -> IO ()
processPythonFile filePath = do
    putStrLn $ "Processando " ++ filePath
    content <- T.readFile filePath

    case parseModule content filePath of
        Left err -> putStrLn $ "Erro de parsing: " ++ show err
        Right (_, mod) -> analyzeModule mod

-- Função que analisa o módulo Python e extrai informações
analyzeModule :: ModeuleSpan -> IO ()
analyzeModule (Module stats) = mapM_ analyzeStatement stats

-- Função que analisa cada statement e extrai informações
analyzeStatement :: StatementSpan -> IO ()
analyzeStatement stats = case stats of
    Fun _ name _ _ _ -> putStrLn $ "Função: " ++ prettyText name
    Class _ name _ _ -> putStrLn $ "Classe: " ++ prettyText name
    While{}          -> putStrLn "Repetição com while: "
    For{}            -> putStrLn "Repetição com for: "
    If{}             -> putStrLn "Condicional if-else-elif"
    _                -> return ()

